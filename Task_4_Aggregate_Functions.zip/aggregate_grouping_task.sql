-- Task 4: Aggregate Functions and Grouping

-- 1. Total salary by department
SELECT department, SUM(salary) AS total_salary
FROM employees
GROUP BY department;

-- 2. Average salary by department
SELECT department, AVG(salary) AS avg_salary
FROM employees
GROUP BY department;

-- 3. Count of employees by role
SELECT role, COUNT(*) AS employee_count
FROM employees
GROUP BY role;

-- 4. Departments with more than 5 employees
SELECT department, COUNT(*) AS employee_count
FROM employees
GROUP BY department
HAVING COUNT(*) > 5;

-- 5. Highest salary by department
SELECT department, MAX(salary) AS max_salary
FROM employees
GROUP BY department;

-- 6. Count of distinct roles
SELECT COUNT(DISTINCT role) AS distinct_roles
FROM employees;