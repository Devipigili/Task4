# Task 4: Aggregate Functions and Grouping

## Objective
Use aggregate functions and GROUP BY clause to summarize data.

## SQL Concepts Used
- SUM, AVG, COUNT, MAX
- GROUP BY and HAVING clauses
- COUNT(DISTINCT column)

## Sample Queries
Includes queries for:
- Total and average salary by department
- Employee count by role and department
- Departments with more than 5 employees
- Highest salary per department

## Tools Used
DB Browser for SQLite / MySQL Workbench

## Output Screenshot
Refer to output_screenshot.png for the sample result.